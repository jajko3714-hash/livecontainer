import SwiftUI

struct LCTabView: View {
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            // Hooks directly into the developer's native unlocked web rendering frame
            LCWebView()
                .edgesIgnoringSafeArea(.all)
        }
    }
}
